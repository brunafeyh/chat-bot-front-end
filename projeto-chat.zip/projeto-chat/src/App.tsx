import './App.css'
import ChatBot from './components/chat-bot'

function App() {

  return (
    <>
     <ChatBot/>
    </>
  )
}

export default App
